const builder = require('botbuilder');
const restify = require('restify');
const githubClient = require('./github-client');

const connector = new builder.ChatConnector();

const bot = new builder.UniversalBot(connector)
    .set('storage', new builder.MemoryBotStorage());

const dialog = new builder.IntentDialog();

dialog.matches(/^search/i, [
    function (session, args, next) {
        if (session.message.text.toLowerCase() === 'search') {
            builder.Prompts.text(session, 'Who are you looking for?');
        } else {
            var query = session.message.text.substring(7);
            next({ response: query });
        }
    },
    function (session, result, next) {
        var query = result.response;
        if (!query) {
            session.endDialog('Request cancelled');
        } else {
            githubClient.executeSearch(query, function (profiles) {

            });
        }
    }
]);

bot.dialog('/', dialog);

const server = restify.createServer();
server.post('/api/messages', connector.listen());
server.listen(3978);
