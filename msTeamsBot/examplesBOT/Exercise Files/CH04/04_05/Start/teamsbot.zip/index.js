const builder = require('botbuilder');
const builderTeams = require('botbuilder-teams');
const restify = require('restify');
const connector = new builderTeams.TeamsChatConnector(
    {
        appId: "d589b12c-f0a2-47dd-861e-85dc41feb629",
        appPassword: "feplf854|;#zyLAHASEF58="
    });

const bot = new builder.UniversalBot(connector)
    .set('storage', new builder.MemoryBotStorage());

const dialog = new builder.IntentDialog();

dialog.matches(/^talk2me/i, [
    function (session, args, next) {
        if (session.message.text.toLowerCase() === 'talk2me') {
            var address =
                {
                    channelId: 'msteams',
                    user: { id: session.message.user.id },
                    channelData: {
                        tenant: {
                            id: session.message.sourceEvent.tenant.id
                        }
                    },
                    bot:
                        {
                            id: 'd589b12c-f0a2-47dd-861e-85dc41feb629',
                            name: 'myCustomTeamsBot3978'
                        },
                    serviceUrl: session.message.address.serviceUrl,                    
                    useAuth: true
                }            
            bot.beginDialog(address, '1on1Dialog')
        }
    }
]);

bot.dialog('1on1Dialog', function (session, args, next) {
    builder.Prompts.text(session,
        'Welcome, this is the start of a new dialog');
});

bot.dialog('/', dialog);

const server = restify.createServer();
server.post('/api/messages', connector.listen());
server.listen(3978);